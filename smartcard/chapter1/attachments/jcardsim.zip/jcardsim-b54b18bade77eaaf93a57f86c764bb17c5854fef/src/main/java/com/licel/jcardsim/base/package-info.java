/**
 * jCardSim simulator base classes.
 */
package com.licel.jcardsim.base;
